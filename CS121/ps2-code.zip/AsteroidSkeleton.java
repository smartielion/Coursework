

import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;

import cs122.GameFrame;
import cs122.UFO;

/**
 * A Skeleton class for creating a simple animation
 * 
 * @author wallaces
 *
 */
public class AsteroidSkeleton extends GameFrame {

	// At this point, you don't know what a 'BufferedImage' is
	// you could google it, but it will probably make things 
	// more confusing rather than less.  Suffice it to say that
	// a BufferedImage is a Java data type for representing a
	// graphic image and will is pass it to a method that will 
	// draw it on the screen... 
	// otherwise you can (AND SHOULD) treat this as a black box.  
	// That's a big benefit of the OOP paradigm!
	private BufferedImage asteroidImage;
	private BufferedImage ufoImage;
	private UFO ufo;
	private double timePassed;
	
	/**
	 * Create a new AsteroidSkeleton class for creating the animation
	 * 
	 * This base implementation loads the images for the asteroid and ufo
	 * and creates a new ufo
	 * 
	 * @param maxAsteroids the maximum number of asteroids to be displayed
	 */
	public AsteroidSkeleton(int maxAsteroids) {
		super(800, 600);
		asteroidImage = loadImage("cs122/small-asteroid.png");
		ufoImage = loadImage("cs122/small-ufo.png");
		
		// make a stationary ufo...
		ufo = new UFO(400,300,0,0);
	}
	
	
	/**
	 * This method overrides update() in the GameFrame class
	 */
	public void update() {
		super.update(); // do whatever the base class (GameFrame) would have done...
	
		timePassed += getDeltaTime();
		
		if (timePassed > 5.0 && ufo.getXVelocity() == 0.0 && ufo.getYVelocity() == 0.0) {
			// start moving slowly...
			System.out.println("5 seconds is up!");
			ufo.setVelocity(20, 20);
		}
		
		// call the update method on each asteroid
		// and the ufo here... 
		ufo.update(getDeltaTime());
		
		// any other code to 
		// change the ufo behavior over time, should
		// probably go here...
	}

	/**
	 * This method overrides render() in the GameFrame class
	 */
	public void render(Graphics g) {
		super.render(g);
		
		// draw each image for example:
		drawImageAt((Graphics2D) g, ufoImage, ufo.getX(), ufo.getY(), 0.0); 
	}

	/**
	 * The entry method used when the class is run as an application
	 * 
	 * Here, we create a new AsteroidSkeleton and call it's run method...
	 * 
	 * @param args (not used)
	 */
	public static void main(String [] args) {
		AsteroidSkeleton ask = new AsteroidSkeleton(1);
		ask.run();
	}
}
